import socket

host = "0.0.0.0"  # Listen on all interfaces
port = 7862

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((host, port))
server.listen(1)
print(f"Listening on {host}:{port}...")

client_socket, client_address = server.accept()
print(f"Connection from {client_address}")

while True:
    command = input("Enter command: ")
    if command.lower() == "exit":
        client_socket.send(b"exit")
        break
    client_socket.send(command.encode())

    result = client_socket.recv(4096).decode()
    print(result)

server.close()